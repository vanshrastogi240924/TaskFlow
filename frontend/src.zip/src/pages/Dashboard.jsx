import { Link } from "react-router-dom";
import { useContext, useState } from "react";
import { TaskContext } from "../context/TaskContext";
import { AuthContext } from "../context/AuthContext";

function Dashboard() {
  const { tasks, deleteTask, toggleComplete, editTask } = useContext(TaskContext);
  const { user, logout } = useContext(AuthContext);

  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [editingId, setEditingId] = useState(null);
  const [editedTitle, setEditedTitle] = useState("");

  const completedTasks = tasks.filter((task) => task.completed).length;
  const pendingTasks = tasks.filter((task) => !task.completed).length;

  const overdueTasks = tasks.filter(
    (task) => !task.completed && new Date(task.deadline) < new Date()
  ).length;

  const completionRate =
    tasks.length === 0
      ? 0
      : Math.round((completedTasks / tasks.length) * 100);

  // Capitalize name helper
  const displayName = user?.name
    ? user.name.charAt(0).toUpperCase() + user.name.slice(1)
    : "User";

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Header */}
      <header className="bg-white shadow p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-cyan-700">TaskFlow</h1>

        <div className="flex gap-2 items-center">
          <Link
            to="/calendar"
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition"
          >
            Calendar
          </Link>

          <Link
            to="/add-task"
            className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-lg text-sm transition mr-2"
          >
            Add Task
          </Link>

          <button
            onClick={logout}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm transition cursor-pointer"
          >
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold">Good Morning, {displayName} 👋</h2>
        <p className="text-gray-600 mt-2">Welcome back to your dashboard.</p>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mt-6">
          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="text-gray-500 text-sm font-medium">Total Tasks</h3>
            <p className="text-3xl font-bold mt-1">{tasks.length}</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="text-gray-500 text-sm font-medium">Completed</h3>
            <p className="text-3xl font-bold text-green-600 mt-1">{completedTasks}</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="text-gray-500 text-sm font-medium">Pending</h3>
            <p className="text-3xl font-bold text-orange-500 mt-1">{pendingTasks}</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow">
            <h3 className="text-gray-500 text-sm font-medium">Completion Rate</h3>
            <p className="text-3xl font-bold text-blue-600 mt-1">{completionRate}%</p>
            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${completionRate}%` }}
              ></div>
            </div>
          </div>
        </div>

        {overdueTasks > 0 && (
          <div className="mt-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            ⚠ {overdueTasks} Overdue Task(s)
          </div>
        )}

        {/* Controls */}
        <div className="mt-8 flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full md:max-w-md border bg-white p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />

          <div className="flex items-center gap-2">
            <label className="text-gray-600 font-medium text-sm">Filter Category:</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="border bg-white p-2.5 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option>All</option>
              <option>Placement</option>
              <option>DSA</option>
              <option>Web Development</option>
              <option>College</option>
              <option>Personal</option>
            </select>
          </div>
        </div>

        {/* My Tasks */}
        <div className="mt-6">
          <h2 className="text-2xl font-bold mb-4">My Tasks</h2>

          {tasks.length === 0 ? (
            <div className="bg-white p-8 text-center rounded-xl shadow">
              <p className="text-gray-500">No tasks added yet. Click "Add Task" to create one!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {tasks
                .filter((task) =>
                  task.title.toLowerCase().includes(searchTerm.toLowerCase())
                )
                .filter(
                  (task) =>
                    categoryFilter === "All" || task.category === categoryFilter
                )
                .map((task) => {
                  const isOverdue =
                    !task.completed && new Date(task.deadline) < new Date();
                  return (
                    <div
                      key={task._id}
                      className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition hover:shadow-md"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          {editingId === task._id ? (
                            <input
                              value={editedTitle}
                              onChange={(e) => setEditedTitle(e.target.value)}
                              className="border p-2 rounded w-full max-w-md focus:outline-none focus:ring-2 focus:ring-cyan-500"
                            />
                          ) : (
                            <h3 className="text-lg font-bold text-gray-800 truncate">
                              {task.title}
                            </h3>
                          )}
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                              task.priority === "High"
                                ? "bg-red-100 text-red-700"
                                : task.priority === "Medium"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-700"
                            }`}
                          >
                            {task.priority}
                          </span>
                          <span className="px-2.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                            {task.category}
                          </span>
                        </div>

                        <div className="flex flex-wrap gap-4 mt-2 items-center text-sm text-gray-500">
                          <span className={isOverdue ? "text-red-600 font-bold" : ""}>
                            📅 Deadline: {task.deadline}
                          </span>
                          <span>
                            Status:{" "}
                            {task.completed ? (
                              <span className="text-green-600 font-semibold">✅ Completed</span>
                            ) : (
                              <span className="text-orange-500 font-semibold">⏳ Pending</span>
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-2 w-full md:w-auto justify-end">
                        <button
                          onClick={() => toggleComplete(task._id)}
                          className="bg-green-500 hover:bg-green-600 text-white px-3 py-1.5 rounded text-sm transition cursor-pointer"
                        >
                          {task.completed ? "Undo" : "Complete"}
                        </button>

                        {editingId === task._id ? (
                          <button
                            onClick={() => {
                              editTask(task._id, { title: editedTitle });
                              setEditingId(null);
                            }}
                            className="bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1.5 rounded text-sm transition cursor-pointer"
                          >
                            Save
                          </button>
                        ) : (
                          <button
                            onClick={() => {
                              setEditingId(task._id);
                              setEditedTitle(task.title);
                            }}
                            className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1.5 rounded text-sm transition cursor-pointer"
                          >
                            Edit
                          </button>
                        )}

                        <button
                          onClick={() => deleteTask(task._id)}
                          className="bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded text-sm transition cursor-pointer"
                        >
                          Delete
                        </button>

                        <Link
                          to="/task-details"
                          state={{ task }}
                          className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1.5 rounded text-sm text-center transition"
                        >
                          View
                        </Link>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default Dashboard;
import { createContext, useState, useEffect, useContext } from "react";
import { AuthContext } from "./AuthContext";

export const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const { token } = useContext(AuthContext);

  // Fetch all tasks for the logged in user
  const fetchTasks = async () => {
    if (!token) return;
    try {
      const response = await fetch("http://localhost:5000/api/tasks", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        // Backend returns ISO deadline. We'll format to YYYY-MM-DD for easier display/inputs
        const formattedTasks = data.map((task) => ({
          ...task,
          deadline: task.deadline ? task.deadline.substring(0, 10) : "",
        }));
        setTasks(formattedTasks);
      }
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  // Fetch tasks automatically when token changes
  useEffect(() => {
    if (token) {
      fetchTasks();
    } else {
      setTasks([]);
    }
  }, [token]);

  // Add Task
  const addTask = async (taskData) => {
    if (!token) return false;
    try {
      const response = await fetch("http://localhost:5000/api/tasks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(taskData),
      });

      if (response.ok) {
        const newTask = await response.json();
        const formattedNewTask = {
          ...newTask,
          deadline: newTask.deadline ? newTask.deadline.substring(0, 10) : "",
        };
        setTasks((prevTasks) => [formattedNewTask, ...prevTasks]);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error adding task:", error);
      return false;
    }
  };

  // Delete Task
  const deleteTask = async (id) => {
    if (!token) return false;
    try {
      const response = await fetch(`http://localhost:5000/api/tasks/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        setTasks((prevTasks) => prevTasks.filter((task) => task._id !== id));
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error deleting task:", error);
      return false;
    }
  };

  // Edit Task
  const editTask = async (id, updatedFields) => {
    if (!token) return false;
    try {
      const response = await fetch(`http://localhost:5000/api/tasks/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updatedFields),
      });

      if (response.ok) {
        const updatedTask = await response.json();
        const formattedTask = {
          ...updatedTask,
          deadline: updatedTask.deadline ? updatedTask.deadline.substring(0, 10) : "",
        };
        setTasks((prevTasks) =>
          prevTasks.map((task) => (task._id === id ? formattedTask : task))
        );
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error editing task:", error);
      return false;
    }
  };

  // Toggle complete
  const toggleComplete = async (id) => {
    const task = tasks.find((t) => t._id === id);
    if (!task) return;

    return await editTask(id, { completed: !task.completed });
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        fetchTasks,
        addTask,
        deleteTask,
        editTask,
        toggleComplete,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};